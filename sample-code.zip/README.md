# To Try the sample 
- install modules 
    `npm install`
- run the sample 
    `npm start`

# remarks 
    This sample only remains the logic flow of shopping dialog (where the issue has happend in prod environment) and removes all the unrelated functions, middleware and modules. For example, the real project uses conversational Language understaing (CLU) model to help get intent and entity of user input. But here, the sample store those intent and entity in a json file and matche them to related input. Just keep it simple for the test

    

